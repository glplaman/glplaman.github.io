<template>
  <div class="cart">
    <header>
      <input type="checkbox" name="all" id="all">
      <label for="all">
        <span>已选择商品 (<span>8</span>) 件</span>
      </label>
      <span><span class="iconfont icon-shoppingcart"></span>清空购物车</span>
    </header>
    <div class="item">
      <input type="checkbox" name="cart" value="cart">
      <span class="title">luckin</span>
      <span class="price">&yen;88</span>
      <button class="btn dec">-</button>
      <span class="quantity">88</span>
      <button class="btn">+</button>
    </div>
    <div class="tips">Tips</div>
    <ol>
      <li>购物车仓库 cart.js √</li>
      <li>视图静态结构 √</li>
      <li>购物车数据 cartLists 加载并渲染</li>
      <li>订单数据 selectedLists</li>
      <li>全选标记 isAll</li>
      <li>全选数据双向绑定</li>
      <li>单选数据双向绑定</li>
      <li>监听订单数据变化 watch()</li>
      <li>全选改变 @change</li>
      <li>数量增加 inc() /减少 dec()</li>
      <li>总价计算 totalPrice</li>
      <li>优惠计算 discountPrice</li>
      <li>数量统计 sum</li>
    </ol>
    <footer>
      <div class="order">
        <div class="logo">
          <span>8</span>
        </div>
        <div class="info">
          <p class="price">预计到手<span>&yen;88</span></p>
          <p class="discount">已享受更多优惠，共减免 <span>&yen;88</span></p>
        </div>
        <button class="order-btn">去结算</button>
      </div>
    </footer>
  </div>
</template>

<script setup>
</script>

<style scoped>
header {
  display: flex;
  align-items: center;
  gap: var(--p-m-g);
  padding: 0 var(--p-m-g);
  margin-bottom: var(--p-m-g);
}

header label {
  margin-right: auto;
}

.item {
  display: flex;
  align-items: center;
  margin-bottom: var(--p-m-g);
  gap: var(--p-m-g);
  padding: 0 var(--p-m-g);
}

.title,
.price {
  flex: 1;
}

.quantity,
.btn {
  width: 24px;
  height: 24px;
  line-height: 24px;
  text-align: center;
}

.btn {
  border-radius: 50%;
  background-color: var(--main-color);
  border: 1px solid var(--main-color);
  color: #fff;
}

.btn.dec {
  background-color: #fff;
  border: 1px solid var(--main-color);
  color: var(--main-color);
}

footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  height: var(--main-nav-h);
  background-color: #fff;
}

.order {
  display: flex;
  align-items: center;
  gap: var(--p-m-g);
  width: 96%;
  height: 60px;
  margin: auto;
  background-color: #fff;
  border-radius: 30px;
  overflow: hidden;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.order .logo {
  position: relative;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: #eee;
  margin-left: var(--p-m-g);
}

.order .logo span {
  position: absolute;
  right: -6px;
  top: -6px;
}

.order .info {
  flex: 1;
}

.order .price {
  font-size: 16px;
}

.order .price span {
  color: #f40;
  font-weight: 600;
}

.order .discount {
  font-size: 12px;
}

.order .order-btn {
  width: 120px;
  height: 100%;
  background-color: var(--main-color);
  color: #fff;
  font-size: 20px;
}

/* other */
.tips {
  text-align: center;
  border-bottom: 1px solid #eee;
  margin-top: 60px;
}

ol {
  margin-left: 20px;
}
</style>